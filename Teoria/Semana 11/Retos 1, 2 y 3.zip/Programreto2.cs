﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PruebaVector3
{
    class PruebaVector3
    {
        private int[] niveles;
        private int[] ninos;
        private int[] adultos;
        private string[] responsable;

        public void Cargar()
        {
            niveles = new int[2];
            ninos = new int[2];
            adultos = new int[2];
            responsable = new string[2];

            int i = 0;
            for (int f = 0; f < 2; f++)
            {
                Console.WriteLine("ingrese el ancargado de nivel");
                responsable[f] = Console.ReadLine();
                Console.Write("Poner personas por nivel: ");
                String linea;
                linea = Console.ReadLine();
                niveles[f] = int.Parse(linea);
                Console.Write("Poner ninos por nivel: ");
                String line;
                line = Console.ReadLine();
                ninos[f] = int.Parse(line);
                Console.Write("Poner adultos por nivel: ");
                String lin;
                lin = Console.ReadLine();
                adultos[f] = int.Parse(lin);
                
                
            }
        }
        public void totalniveles()
        {
            int man = 0;
            int ni=0;
            int adu = 0;
            for (int f = 0; f < 2; f++)
            {
                man = man + niveles[f];
                ni = ni + ninos[f];
                adu = adu + adultos[f];
                Console.WriteLine("El encargado por nivel es: "+ responsable[f]);

            }
            Console.WriteLine("Total de personas por todos los niveles:" + man);
            Console.WriteLine("Total de ninos por todos los niveles:" + ni);
            Console.WriteLine("Total de adultos por todos los niveles:" + adu);
            


            Console.ReadKey();
        }
        
        static void Main(string[] args)
        {
            PruebaVector3 pv = new PruebaVector3();
            pv.Cargar();
            pv.totalniveles();
        }
    }
}

