﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Mi segundo programa");
            Console.ReadKey();
            Console.WriteLine("Ingrese su nombre");
            string nombre = Console.ReadLine();
            Console.WriteLine("Ingrese su edad");
            string edad = Console.ReadLine();
            Console.WriteLine("Ingrese su carrera");
            string carrera = Console.ReadLine();
            Console.WriteLine("Ingrese su carné");
            string carne = Console.ReadLine();
            Console.WriteLine("Hola");
            Console.Write("soy " + nombre + " tengo "  + edad + " años y estudio " + carrera + " y mi número de carné es " + carne);
            Console.ReadKey();
        }
    }
}
